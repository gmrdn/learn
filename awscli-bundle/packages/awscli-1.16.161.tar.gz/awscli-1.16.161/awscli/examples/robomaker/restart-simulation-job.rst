**To restart a simulation**

This example restarts a simulation.

Command::

   aws robomaker restart-simulation-job --job arn:aws:robomaker:us-west-2:111111111111:simulation-job/sim-t6rdgt70mftr
