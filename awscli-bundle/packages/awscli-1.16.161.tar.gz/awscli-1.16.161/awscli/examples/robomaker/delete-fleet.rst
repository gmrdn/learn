**To delete a fleet**

This example deletes a fleet.

Command::

   aws robomaker delete-fleet --fleet arn:aws:robomaker:us-west-2:111111111111:deployment-fleet/MyFleet/1550771394395
