**To delete a user**

This example deletes a user.

Command::

  aws workdocs delete-user --user-id "S-1-1-11-1111111111-2222222222-3333333333-3333&d-926726012c"

Output::

  None